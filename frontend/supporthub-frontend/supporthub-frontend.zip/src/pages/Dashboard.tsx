import Card from "../components/Card";

export default function Dashboard() {
  return (
    <div className="grid gap-6 md:grid-cols-3">
      <Stat title="Open Tickets" value="12" />
      <Stat title="In Progress" value="5" />
      <Stat title="Resolved Today" value="3" />
    </div>
  );
}

function Stat({ title, value }: { title: string; value: string }) {
  return (
    <Card className="p-5">
      <p className="text-sm text-slate-400">{title}</p>
      <p className="mt-2 text-3xl font-bold">{value}</p>
      <div className="mt-4 h-1.5 rounded-full bg-white/5 overflow-hidden">
        <div className="h-full w-2/3 bg-linear-to-r from-[rgb(var(--brand))] to-[rgb(var(--brand2))]" />
      </div>
    </Card>
  );
}
