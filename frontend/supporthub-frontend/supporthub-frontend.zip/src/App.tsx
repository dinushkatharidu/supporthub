export default function App() {
  console.log("API URL =", import.meta.env.VITE_API_BASE_URL);

  return (
    <div className="min-h-screen grid place-items-center">
      <h1 className="text-3xl font-bold underline">Tailwind Working ✅</h1>
    </div>
    
  );
}

