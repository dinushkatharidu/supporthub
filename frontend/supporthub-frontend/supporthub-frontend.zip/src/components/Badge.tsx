import { cn } from "../utils/cn";

export type TicketStatus = "OPEN" | "IN_PROGRESS" | "RESOLVED" | "CLOSED";

export default function Badge({
  status,
  className,
}: {
  status: TicketStatus;
  className?: string;
}) {
  const map: Record<TicketStatus, string> = {
    OPEN: "bg-white/10 text-slate-200 border-white/10",
    IN_PROGRESS:
      "bg-[rgba(251,191,36,0.15)] text-[rgb(var(--warn))] border-[rgba(251,191,36,0.3)]",
    RESOLVED:
      "bg-[rgba(52,211,153,0.12)] text-[rgb(var(--ok))] border-[rgba(52,211,153,0.3)]",
    CLOSED: "bg-white/5 text-slate-400 border-white/10",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold",
        map[status],
        className
      )}
    >
      {status.replace("_", " ")}
    </span>
  );
}
